import { IconInfo } from "../types";
export declare const ICON_LIST: IconInfo[];
export declare const ICON_NAMES: import("../types").IconName[];
