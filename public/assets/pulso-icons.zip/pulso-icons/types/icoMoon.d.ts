export type IconSetItem = {
    properties: {
        name: string;
    };
    icon: {
        paths: string[];
        attrs: Record<string, unknown>[];
        width?: number | string;
    };
};
export type IconSet = {
    icons: IconSetItem[];
};
