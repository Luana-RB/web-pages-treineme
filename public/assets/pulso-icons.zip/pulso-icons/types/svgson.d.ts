export interface svgson {
    name: string;
    type: string;
    value: string;
    attributes: Record<string, string | undefined>;
    children: svgson[];
}
